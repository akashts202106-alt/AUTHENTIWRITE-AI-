"""Optional Python API for AuthentiWrite AI.
This minimal Flask API is a separate backend example. The supplied web UI currently
runs its analysis locally in JavaScript and does not require this API.
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import re
from collections import Counter

app = Flask(__name__)
CORS(app)  # For local development only; restrict origins before deployment.

def analyze_text(text: str) -> dict:
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', text.strip()) if s.strip()]
    tokens = re.findall(r"\b[\w'-]+\b", text.lower(), flags=re.UNICODE)
    if len(tokens) < 20:
        raise ValueError("Please provide at least 20 words for a basic summary.")
    lengths = [len(re.findall(r"\b[\w'-]+\b", s)) for s in sentences]
    counts = Counter(tokens)
    return {
        "word_count": len(tokens),
        "sentence_count": len(sentences),
        "unique_word_count": len(counts),
        "type_token_ratio": round(len(counts) / len(tokens), 4),
        "average_sentence_length": round(sum(lengths) / len(lengths), 2) if lengths else 0,
        "notice": "Descriptive statistics only; these values cannot establish authorship."
    }

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "project": "AuthentiWrite AI"})

@app.post("/api/analyze")
def analyze():
    payload = request.get_json(silent=True) or {}
    text = payload.get("text", "")
    if not isinstance(text, str):
        return jsonify({"error": "'text' must be a string"}), 400
    try:
        return jsonify(analyze_text(text))
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

if __name__ == "__main__":
    # Development only. Do not expose Flask's debug server publicly.
    app.run(host="127.0.0.1", port=5000, debug=True)
