# AuthentiWrite AI — Website Prototype

## Files
- `index.html` — website structure
- `style.css` — styling and responsive layout
- `script.js` — browser-based writing-signal prototype
- `app.py` — optional Python/Flask API example
- `requirements.txt` — Python dependencies

## Fastest preview
Open `index.html` in a browser. The front end uses JavaScript for its analysis and does not need Python to run.

## Use in Google Colab
1. Download and upload this ZIP to Google Drive or directly into Colab.
2. In Colab, run:

```python
from google.colab import files
uploaded = files.upload()  # choose AuthentiWrite_AI_Website.zip
```

3. Extract it:

```python
import zipfile, os
with zipfile.ZipFile("AuthentiWrite_AI_Website.zip") as z:
    z.extractall("/content/AuthentiWrite_AI_Website")
os.listdir("/content/AuthentiWrite_AI_Website")
```

4. To install and test the optional Python API:

```python
%cd /content/AuthentiWrite_AI_Website
!pip install -r requirements.txt
!python -c "from app import app; print(app.url_map)"
```

Colab is a notebook environment, not permanent web hosting. For a public website, deploy the static front end to a static host and deploy the Python API separately if you need it. Configure allowed origins and HTTPS before public deployment.

## Important limitations
The score in this demo is an illustrative heuristic indicator, not a validated AI-writing detector or calibrated probability. It must not be used as proof of authorship. CrossRef verification, factual-claim extraction, model-assisted predictability, and a validated weighted scoring system are not yet implemented in this starter prototype.
