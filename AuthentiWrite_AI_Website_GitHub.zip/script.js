const essay = document.getElementById('essay');
const counts = document.getElementById('counts');
const results = document.getElementById('results');
const errorBox = document.getElementById('error');
let latestReport = null;

function splitSentences(text) {
  return (text.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || []).map(s => s.trim()).filter(Boolean);
}
function words(text) { return text.toLowerCase().match(/\b[\p{L}\p{N}'’-]+\b/gu) || []; }
function mean(arr) { return arr.length ? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }
function stddev(arr) { const m=mean(arr); return Math.sqrt(mean(arr.map(x=>(x-m)**2))); }
function round(n) { return Math.round(n*100)/100; }
function updateCounts() {
  const w=words(essay.value).length, s=splitSentences(essay.value).length;
  counts.textContent = `${w} words · ${s} sentences`;
}
essay.addEventListener('input', updateCounts);
document.getElementById('clearBtn').addEventListener('click',()=>{essay.value='';updateCounts();results.hidden=true;errorBox.hidden=true;});
document.getElementById('demoBtn').addEventListener('click',()=>{
  essay.value = 'Clear communication helps people understand complex ideas. For example, a useful report defines its terms before presenting evidence. In addition, the writer should explain how each conclusion follows from the observations. These choices make the document easier to review. Clear communication also benefits readers who have different levels of background knowledge.';
  updateCounts();
});
function analyze(text) {
  const sentences=splitSentences(text), tokens=words(text), lengths=sentences.map(s=>words(s).length);
  if(tokens.length<20) throw new Error('Please enter at least 20 words. Short samples provide too little evidence for meaningful signal summaries.');
  const unique=new Set(tokens);
  const ttr=unique.size/tokens.length;
  const cv=mean(lengths) ? stddev(lengths)/mean(lengths) : 0;
  const transitions=['in addition','moreover','furthermore','however','therefore','for example','consequently','in conclusion','on the other hand'];
  const lower=text.toLowerCase();
  const transitionHits=transitions.reduce((n,p)=>n+(lower.match(new RegExp('\\b'+p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','g'))||[]).length,0);
  const repeatedPairs = tokens.slice(0,-1).reduce((acc,w,i)=>{const pair=w+' '+tokens[i+1];acc.total++;if(i>0&&tokens[i-1]+' '+tokens[i]===pair)acc.repeat++;return acc;},{total:0,repeat:0});
  const metrics=[
    {name:'Sentence-length variation',value:Math.min(100,cv*160),detail:`Average sentence length: ${round(mean(lengths))} words; variation coefficient: ${round(cv)}. Uniform lengths can occur in both human and AI writing.`},
    {name:'Vocabulary variety',value:(1-ttr)*100,detail:`${unique.size} unique words among ${tokens.length} words (type-token ratio ${round(ttr)}). Topic and sample length affect this measure.`},
    {name:'Transition phrase reuse',value:Math.min(100,transitionHits/Math.max(1,sentences.length)*180),detail:`Found ${transitionHits} occurrences of common transition phrases. Their presence is not evidence of authorship by itself.`},
    {name:'Repeated adjacent phrases',value:Math.min(100,(repeatedPairs.repeat/Math.max(1,tokens.length-1))*1000),detail:'Checks immediate repeated two-word sequences; repetition can be intentional or topic-dependent.'}
  ];
  // Deliberately labelled a heuristic indicator, not a probability or validated detector.
  const score=Math.round(metrics.reduce((a,m)=>a+m.value,0)/metrics.length);
  const observations=sentences.slice(0,12).map(s=>{
    const n=words(s).length;
    let reason=n>30?'Long sentence: consider whether it contains several ideas.':n<6?'Short sentence: may be effective for emphasis; inspect in context.':'No simple length flag. This does not establish whether the sentence is human- or AI-written.';
    return {text:s,reason};
  });
  return {score,metrics,observations,wordCount:tokens.length,sentenceCount:sentences.length};
}
function esc(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
document.getElementById('analyzeBtn').addEventListener('click',()=>{
  errorBox.hidden=true;
  try{
    const report=analyze(essay.value); latestReport=report;
    document.getElementById('score').textContent=report.score;
    document.getElementById('scoreText').textContent='Heuristic pattern indicator — not an AI probability';
    document.getElementById('signalCount').textContent=report.metrics.length;
    document.getElementById('signals').innerHTML=report.metrics.map(m=>`<div class="signal"><div class="signal-top"><span>${esc(m.name)}</span><span>${Math.round(m.value)} / 100</span></div><div class="meter"><span style="width:${Math.min(100,m.value)}%"></span></div><p>${esc(m.detail)}</p></div>`).join('');
    document.getElementById('sentences').innerHTML=report.observations.map((s,i)=>`<div class="sentence"><p><strong>${i+1}.</strong> ${esc(s.text)}</p><small>${esc(s.reason)}</small></div>`).join('');
    results.hidden=false; results.scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){errorBox.textContent=e.message;errorBox.hidden=false;}
});
document.getElementById('downloadBtn').addEventListener('click',()=>{
  if(!latestReport)return;
  const body=['AuthentiWrite AI — Heuristic Signal Report','IMPORTANT: This is not a calibrated AI detector or proof of authorship.','',`Words: ${latestReport.wordCount}`,`Sentences: ${latestReport.sentenceCount}`,`Pattern indicator: ${latestReport.score}/100`,'',...latestReport.metrics.map(m=>`${m.name}: ${round(m.value)}/100\n${m.detail}`),'','Sentence observations:',...latestReport.observations.map((s,i)=>`${i+1}. ${s.text}\n   ${s.reason}`)].join('\n');
  const url=URL.createObjectURL(new Blob([body],{type:'text/plain;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='authentiwrite-report.txt';a.click();URL.revokeObjectURL(url);
});
updateCounts();